/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keluar;

/**
 *
 * @author Dan
 */
public class Karyawan2 {
    String nama2;
    String Gender2;
    
    public void id(){
        System.out.println("Berikut identitas pegawai:");
        System.out.println("nama = "+nama2);
        System.out.println("Jenis kelamin = "+Gender2);
    }
}
