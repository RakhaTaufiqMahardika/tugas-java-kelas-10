/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keluar;

/**
 *
 * @author Dan
 */
public class Karyawan {
    String nama;
    String Gender;
    
    public void id(){
        System.out.println("Berikut identitas pegawai:");
        System.out.println("nama = "+nama);
        System.out.println("Jenis kelamin = "+Gender);
    }
}
